package com.route4me.sdk.examples.addresses;

public class AddAddressToOptimization {

    public static void main(String[] args) {
        //doesn't seem to work currently
    }

}
